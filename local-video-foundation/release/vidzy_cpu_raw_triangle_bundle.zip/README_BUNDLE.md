# Vidzy CPU model bundle quick start

This archive contains model weights and sample outputs, not the Python source code. Download the matching Vidzy source repository, put this ZIP in its `release/` directory, and run commands from the source repository root.

Verify and extract the archive:

```powershell
python tools\verify_cpu_model_bundle.py
Expand-Archive -LiteralPath .\release\vidzy_cpu_raw_triangle_bundle.zip -DestinationPath . -Force
```

Install dependencies as described in the repository `README.md`, then generate a raw small-triangle image:

```powershell
python -m video_foundation.inference.sample_image `
  --checkpoint checkpoints\cpu_triangle_raw_rgb_v90_native_centered_lr5e5\checkpoint_final.pt `
  --small_triangle_checkpoint checkpoints\cpu_triangle_small_raw_rgb_v93_eval_aligned_threshold\checkpoint_final.pt `
  --medium_large_checkpoint checkpoints\cpu_triangle_raw_rgb_v90_native_centered_lr5e5\checkpoint_final.pt `
  --output_dir outputs\bundle_quickstart `
  --num_samples 4 --sampling_steps 50 --seed 5678 `
  --class_label 2 --size small --vary_colors --raw_generation --device cpu
```

The six-second example uses `checkpoints\cpu_video_v37_motion_v90_spatial_composite.pt` for motion, v93 for small spatial anchors, and v90 for medium/large anchors. See the source repository README for the full video command, training recipes, evaluation commands, and current limitations.
