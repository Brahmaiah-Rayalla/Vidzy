# Model bundle provenance

The routed metrics use the recorded fixed-seed evaluations for v90, v91, v92, and v93. Checkpoint hashes below distinguish the original training files from the compact inference files in this archive. The compact files preserve the model weights, configuration, step, and seed while omitting optimizer state.

See `routed_metrics.json` for per-size means and standard deviations. Re-run the evaluation commands in the repository README to create a fresh evaluation on another machine.
